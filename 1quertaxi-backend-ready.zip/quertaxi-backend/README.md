# Quertaxi Backend

API para o aplicativo QUERTAXI com Node.js e Express.
