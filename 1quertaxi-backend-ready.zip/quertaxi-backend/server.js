const express = require('express');
const app = express();
const rideRoutes = require('./routes/rideRoutes');

require('dotenv').config();
app.use(express.json());
app.use('/api/rides', rideRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
